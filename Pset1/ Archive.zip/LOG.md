Meghana Chamarty
mc3547

# Estimate of time to complete assignment
4 hours

# Actual time to complete assignment
| Date | Time Started | Time Spent | Work completed |
| 1/25 | 12:30 pm    | 4 hours    | created hello.c, compiled everything|
| 1/29 | 8:00 pm     | 5 minutes  | submitted|

# Collaboration
I discussed my solution with: TAs

# Discussion
Initially, I had an issue with connecting to the zoo via VSCode. Since I had limited knowlege of C, I had to learn the commands. After getting across the learning curve, the problem set was simple to finish. There was not much troubleshooting involved. 